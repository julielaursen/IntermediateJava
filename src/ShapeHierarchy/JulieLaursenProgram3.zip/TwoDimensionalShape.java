package ShapeHierarchy;

public abstract class TwoDimensionalShape extends Shape {
		
	public double area()
	{
		return 0;
	}
}
