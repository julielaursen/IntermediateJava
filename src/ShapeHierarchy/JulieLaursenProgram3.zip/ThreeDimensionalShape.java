package ShapeHierarchy;

public abstract class ThreeDimensionalShape extends Shape{
	
	public double getArea()
	{
		return 0;
	}
	
	public double getVolume()
	{
		return 0;
	}

}
