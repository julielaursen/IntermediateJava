package Chapter9;

public interface Payable {
	double getPaymentAmount();
}
